Welcome to Doom!

This is a baseset that contains the original soundtrack from the first Doom in midi form.
To load the baseset go to your Options menu and select "DOOM" in the base music section.

The songs from each chapter have been grouped into their chapters.
Old Style is the soundtrack from chapter 1 "Knee deep in the dead".
New Style is the soundtrack from chapter 2 "".
Ezy Street is the soundtrack from chapter 3 "".

It includes repeats from some songs as they are used in multiple chapters.
For this reason I removed "Hell Keep" as it is played twice in a row (e2m9 and e3m1).

May I please note that the Doom soundtrack and sourcecode were publicly released under GNU GPL v2 in 1997 and as such I have released this soundtrack for OpenTTD under the same licence. This is not my original work.

Thank you for reading this, and enjoy your Doom adventures in Open TTD!