Radio MonChrMe, Volume 1, ver 0.0.05 (2017.05.29)
Maintained by MonChrMe (furber.k@outlook.com)

Contents
 Section 1 : Overview Of Content.
 Section 2 : Track Listings.
 Section 3 : Technical Infomation.
 Section 4 : Feedback, FAQ.
 
_______________________________________________________________________________
Section 1 : Overview.

  Tracks have been tailored for the MSGS (stock Windows soft synth), and are
  still being balanced against other synths. If you use a synth or soundfont
  that this pack clearly needs balancing against, let me know what it is and
  where I can find it! Thanks!
  
  Released under a variant of the MIT Expat license - see license.txt for
  details.

  This is a work in progress; if you'd like to submit your own midi sequences
  for inclusion, and are happy to have them released under the terms outlined
  in license.txt, feel free to contact the author at furber.k@outlook.com. For
  legal reasons, I can only accept MIDIs that you have sequenced yourself, and
  that consist of your own compositions. I *cannot* accept sequences of
  existing pop, rock, and other commercial songs.

  Please bear in mind that any tracks submitted may need to be edited to
  adjust volume levels or instrument patches for compatibility.

  All component tracks are available on request.

_______________________________________________________________________________  
Section 2 : Track Listings.  
  
  All subtracks composed and sequenced by MonChrMe (furber.k@outlook.com),
  except as marked otherwise.
  
  Track list as of version 0.0.06;
  
   Track One - Loco Motion!; running time 6m26
    Consists of 2 subTracks, emulating TTD's base style.
	This track is a work in progress, and is included for testing and feedback.
	All subTracks in this channel are new compositions & Sequences, and require
	more testing than the other channels as a result.
	purposes.
	 subTrack 1 : "Kirby, Stahp Breaking Down!"
	 subTrack 2 : "Lost In The Tunnels"
	 subTrack 3 : N/A - WIP, not included in this release.
	 subTrack 4 : N/A - WIP, not included in this release.
	 
   Track Two - Piano Roll; running time 12m48
    Consists of 6 subTracks. The theme is simple piano pieces with a bit of
	character. Some tracks introduce additional accent instruments, such as a
	bit of bass or some backing strings, but the focus is always on the pianos.
	 subTrack 1 : "The Castoff"
	 subTrack 2 : "3Quality"
	 subTrack 3 : "Forest Jaunt"
	 subTrack 4 : "Gello"
	 subTrack 5 : "Not What You Think"
	 subTrack 6 : "Half An Angel"
  
   Track Three - Sounds For Life; running time 13m52s
    Consists of 4 subTracks, themed around retro RPG-like soundtracks.
	Laid back and slow paced, generally using wind, acoustic and string
	instruments.
	 subTrack 1 : "One is One"
	 subTrack 2 : "Half Price Clocks"
	 subTrack 3 : "Painting The Sky"
	 subtrack 4 : "Breathe In"

   Track Four - Groove Radio; Running time 14m43s
    Consists of four sub-tracks, themed around bass or light drum grooves.
	Slow and medium paced tracks with a jazz or funk edge to them.
     subTrack 1 : "The Stone Rose, Radio Version"
     subTrack 2 : "Open Bar"
     subTrack 3 : "You Talkin' At Me?"
     subTrack 4 : "Sun, Sea, and A Seat At The Bar"

   Track Five - Rock, Stock, and Two Smoking Guitars; Running time 12m33s
    Consists of four tracks, themed around industrial rock, NWBHM, and power
	metal. Fast paced tracks featuring guitar solos, galloping bass and lots of
	drums, as well as occasional synths or strings.
     subTrack 1 : "Heavier Metal"
     subTrack 2 : "The Heavy Metal Hero"
     subTrack 3 : "The Albatross"
     subTrack 4 : "Twin Dragons"
	 
   Track Six - DARKWAvE; Running time 11m30s
    Consists of three tracks, themed around 'dark' sounding electronica.
	 subTrack 1 : "Who Let The Dolls Out"
	 subTrack 2 : "World To Be Mine"
	 subTrack 3 : "Inverse Kinetic"
	
   Title Track : "Response Test", Running time 4m54s
    Consists of a single track in a Hard Rock/Heavy Metal style.
_______________________________________________________________________________
Section 3 : Technical Information.

  Tracks by MonChrMe are multitrack MIDI files using the .mid file format,
  using GS instrument patches in addition to GM patches. The instrument patches
  and volume levels are configured for the Windows DirectSound softsynth, which
  itself uses a licensed version of the Roland SC-55 GS patches, with some
  features disabled or otherwise non-functional.
  
  Despite using GS patches, the MIDI files contained in this pack should play
  back correctly on most standard GM (General Midi) hard and softsynths. The GS
  patches are set first by choosing a GM patch, then setting an additional bank
  controller to set the 'variant' of the base GM patch. For example, setting a
  channel to GM patch 80 selects the instrument "Synth Square Wave", which is a
  standard GM instrument. Then, setting the bank controller to bank 8 will
  change this to "(Var8) Sine Wave" on a GS enabled synth. A GM-only synth will
  generally ignore the bank controller being set, resulting in that synth
  playing the notes using the square wave instead. Although it's not a perfect
  match, the instrument selected in this way will always be similar to the GS
  instrument, resulting in successful playback of the file.
  
  The 'Master Track' for each 'radio channel' consists of a number of smaller
  midi files that have been manually stitched together. As a result, there are
  tempo changes, channel reassignments, patch and bank changes throughout the
  length of the MIDI. This should not be a problem; the MIDI protocol was
  designed with this flexibility in mind. However, there is the possibility
  that I've missed a controller when setting the files up that causes playback
  issues on some hardware or software. I respectfully request that should such
  a fault be discovered, it be reported to me at the email address at the top
  of this document so I can correct it.
  
  All MIDI files in this pack have been compiled using Evolution Audio v1.43,
  by Stephen J Mellin (copyright assigned to Evolution Electronics Ltd, 1997).
  
  All tracks by MonChrMe composed and sequenced using Evolution Audio v1.43
  
  All tracks and sub-tracks in this pack have been tested on the following
  software synths to ensure compatibility:
    Microsoft GS Software Wavetable Synthesizer, Windows 10 (no version number)
	Midig 1.01 (General Midi), tested under DosBox 0.74
	Coolsoft Virtual Midi Synth 1.10.1 (x86) using SGM-v2.01.sf2 (General Midi)
	
_______________________________________________________________________________
Section 4 : Feedback and FAQ.

  Q01) I'd like to make a suggestion or report a bug. Where to?
  A01) My email address is furber.k@outlook.com.
  
  Q02) Where did all these tracks come from?
  A03) A decade back I was trying to develop an RPG. I made the rookie's
       mistake of biting off way more than I could chew, and it never got
	   anywhere. However, I did compose/sequence a lot of tracks while working
	   on the concept. Many of the tracks I've featured in this pack were
	   created then. Some were more or less complete, and others were little
	   more than a bass line and a drum part; in all cases I've tried to polish
	   them up a bit before including them in the pack.
	   
	   Many other tracks are from my old profile at Laura's Midi Heaven (now
	   defunct, sadly). I used to fire up the sequencer whenever I needed to
	   distract myself, and got quite prolific.
	   
  Q03) Your music sucks!
  A03) That's a matter of opinion. Am I a professional? No, and in fact I have
       no formal education in music and can't play any instruments (or read
	   sheet music). Doesn't matter, I enjoy doing what I do, and when LMH was
	   still alive it was nice seeing comments pop up on the profile. Even if
	   I make mistakes along the way, MIDI files can easily be edited and I try
	   to use licenses that allow people to edit or build on them, use them in
	   school or education projects, and so on.
	   
  Q04) Can I get my music into the pack?
  A04) Possibly - drop me a line if you want to try. I'm likely to accept music
       for inclusion as long as it works well on the MS-GS-SWS (see section 3),
	   as that's what almost all Windows users use (I'm not sure Linux has a
	   common MIDI configuration?). It's also dependant on me being able to get
       enough tracks in a common style together to make up a channel - or being
       able to slot it into an existing one.

       Don't worry too much if things are looking full; there's a reason it
       says "Volume 1" at the top of the file. When this pack's starting to
	   look too full to expand, I'll be starting another. :)
	   
	   There's two other requirements that I hope are obvious; You *must* be
	   willing to release the track under the terms of license.txt, and you
	   *must* have the necessary rights under copyright law to release the
	   track. That basically means you have to have composed it yourself
	   (unless the track is old enough that it's copyright has expired, or you
	   had it composed for you as a "work for hire" - I'll need to see evidence
	   in the latter case just to make sure the contractor released the
	   necessary rights to you) and *must* have sequenced it yourself (or had
	   it sequenced for you as a "work for hire"; again, I'll need evidence if
	   that is the case).
	   
	   The TL:DR; for that is that if you send me a MIDI of a Lady Gaga track,
	   I'll tell you to sod off. Politely, of course. :)
	   
  Q05) Can I use any of this music in another project/at school/on youtube?
  A05) Yes! Just make sure you comply with the terms of license.txt - it's
       short and sweet, and not hard to do. No, you don't need to pay me -
	   although if you're using it commercially or selling it, I wouldn't mind
	   a cut. :P
	   
	   It's not a formal requirement, but I'd love it if you drop me a line if
	   you do use any of the featured music. I'm sure the same is true for any
	   other featured artists in the pack (there aren't any at the time of
	   writing, but that can change). It always nice to see where things end
	   up, and what people do with them.
	   
  Q06) Just to clarify, I can edit tracks/create derivative works?
  A06) Again, Yes! You'll still need to include the copyright notice if you
       distribute the derivative work, but it's easy to add a blurb explaining
	   that the notice applies to the source track, and you've modified it.
	   
	   The whole point behind that is that people can track down the source if
	   they need to - and people don't try to enforce a copyright that's not
	   theirs to enforce.
	   
  Q07) None of this is traditional TTD music. You sure it fits?
  A07) Yup. Chances are that when you're commuting, you've got the radio
       playing, or a passenger channel surfing. There's no single style of
	   music that people listen to on the move; some get the dance tracks
	   going, others rock out, others find something they can chill to.
	   Others just listen to whatever happens to be playing.
	   
	   More important than the specific style of music used for OpenTTD is the
	   format of the music; MIDI, chiptunes, and the likes match the graphical
	   style well, so don't detract from the game (unless you don't like the
	   track playing). MP3/Vorbis/FLACC tracks with crazy production values, on
	   the other hand, would create a mismatch between what people see and what
	   people hear. It would be the equilavent of the latest "Call Of Duty"
	   game using a soundtrack performed on the soundchip from a FAMICOM - the
	   style wouldn't matter, the quality of music just wouldn't fit the
	   visuals.
	   
  Q08) Website? Social Media?
  A08) None, yet. Personal circumstances would make them difficult to maintain.
  
  Q09) Donations?
  A09) Again, circumstances would make that difficult. I wouldn't feel
       comfortable with it anyway.
	   
  Q10) Are you adding to this? If so, when?
  A10) Yes, and as and when I can. I'm not going to promise a schedule I can't
       keep, but I'll increment the least significant version number with every
	   update, however small, and update the date at the top of this file. That
	   should make it easier to see if there's new content, assuming you're
	   using the in-game content system.
	   
	   If you're really desperate, let me know (email up top), and I'll send
	   you an email notification when I update.
	   
  Q11) Spelhink mistaxE!
  A11) Tell me! :(
	   
*EOF*